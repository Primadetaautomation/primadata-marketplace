// Popup script for Chrome Extension
document.addEventListener('DOMContentLoaded', async () => {
  // Load current status
  await loadStatus();
  await loadHistory();
  await checkConnection();

  // Add event listeners
  document.getElementById('capture-btn').addEventListener('click', captureCurrentProfile);
  document.getElementById('dashboard-btn').addEventListener('click', openDashboard);
  document.getElementById('settings-link').addEventListener('click', openSettings);
});

// Load extension status
async function loadStatus() {
  try {
    const { captureCount = 0, history = [] } = await chrome.storage.local.get(['captureCount', 'history']);

    // Update total count
    document.getElementById('captured-total').textContent = captureCount;

    // Calculate today's captures
    const today = new Date().toDateString();
    const todayCaptures = history.filter(item =>
      new Date(item.capturedAt).toDateString() === today
    ).length;
    document.getElementById('captured-today').textContent = todayCaptures;

    // Calculate this week's captures
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekCaptures = history.filter(item =>
      new Date(item.capturedAt) > weekAgo
    ).length;
    document.getElementById('captured-week').textContent = weekCaptures;

  } catch (error) {
    console.error('Error loading status:', error);
  }
}

// Load capture history
async function loadHistory() {
  try {
    const { history = [] } = await chrome.storage.local.get('history');
    const historyList = document.getElementById('history-list');

    if (history.length === 0) {
      historyList.innerHTML = '<div class="empty-state">No profiles captured yet</div>';
      return;
    }

    // Show last 5 captures
    const recentHistory = history.slice(0, 5);
    historyList.innerHTML = recentHistory.map(item => `
      <div class="history-item">
        <a href="${item.url}" target="_blank">${item.name}</a>
        <div class="meta">${item.title || 'Unknown'} at ${item.company || 'Unknown'}</div>
        <div class="meta">${formatTime(item.capturedAt)}</div>
      </div>
    `).join('');

  } catch (error) {
    console.error('Error loading history:', error);
  }
}

// Check API connection
async function checkConnection() {
  try {
    const { apiUrl, apiKey } = await chrome.storage.sync.get(['apiUrl', 'apiKey']);
    const connectionStatus = document.getElementById('connection-status');
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');

    if (!apiKey) {
      connectionStatus.textContent = 'API key not configured';
      statusDot.classList.add('inactive');
      statusText.textContent = 'Please configure API key';
      return;
    }

    // Try to ping the API
    const response = await fetch(`${apiUrl}/api/health`, {
      headers: { 'x-api-key': apiKey }
    }).catch(() => null);

    if (response && response.ok) {
      connectionStatus.textContent = 'Connected to CRM';
      statusDot.classList.remove('inactive');
      statusText.textContent = 'Ready to capture profiles';
    } else {
      connectionStatus.textContent = 'Cannot connect to API';
      statusDot.classList.add('inactive');
      statusText.textContent = 'Check API configuration';
    }

  } catch (error) {
    console.error('Connection check error:', error);
    document.getElementById('connection-status').textContent = 'Connection error';
  }
}

// Capture current profile
async function captureCurrentProfile() {
  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url || !tab.url.includes('linkedin.com/in/')) {
      alert('Please navigate to a LinkedIn profile page first');
      return;
    }

    // Disable button and show loading
    const button = document.getElementById('capture-btn');
    button.disabled = true;
    button.textContent = 'Capturing...';

    // Send message to content script
    chrome.tabs.sendMessage(tab.id, { action: 'triggerCapture' }, async (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error:', chrome.runtime.lastError);
        alert('Error: Please refresh the LinkedIn page and try again');
      } else {
        // Refresh status
        await loadStatus();
        await loadHistory();
      }

      // Re-enable button
      button.disabled = false;
      button.textContent = 'Capture Current Profile';
    });

  } catch (error) {
    console.error('Capture error:', error);
    alert('Error capturing profile: ' + error.message);
  }
}

// Open dashboard
async function openDashboard() {
  const { apiUrl } = await chrome.storage.sync.get('apiUrl');
  const dashboardUrl = apiUrl.replace('/api', '').replace(':3000', ':5173');
  chrome.tabs.create({ url: dashboardUrl });
}

// Open settings
function openSettings(e) {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
}

// Format time helper
function formatTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;

  // Less than 1 hour
  if (diff < 3600000) {
    const minutes = Math.floor(diff / 60000);
    return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
  }

  // Less than 24 hours
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
  }

  // Less than 7 days
  if (diff < 604800000) {
    const days = Math.floor(diff / 86400000);
    return `${days} day${days !== 1 ? 's' : ''} ago`;
  }

  // Otherwise show date
  return date.toLocaleDateString();
}