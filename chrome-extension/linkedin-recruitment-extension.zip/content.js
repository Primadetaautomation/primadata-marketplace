// Content script for LinkedIn profile extraction
console.log('Recruitment Outreach Engine: Content script loaded');

// Function to extract profile data from LinkedIn page
function extractProfileData() {
  const profile = {
    url: window.location.href,
    fullName: '',
    firstName: '',
    lastName: '',
    headline: '',
    currentTitle: '',
    currentCompany: '',
    location: '',
    about: '',
    experience: [],
    education: [],
    skills: [],
    profileImageUrl: ''
  };

  try {
    // Extract name
    const nameElement = document.querySelector('h1.text-heading-xlarge');
    if (nameElement) {
      profile.fullName = nameElement.innerText.trim();
      const nameParts = profile.fullName.split(' ');
      profile.firstName = nameParts[0];
      profile.lastName = nameParts.slice(1).join(' ');
    }

    // Extract headline
    const headlineElement = document.querySelector('.text-body-medium.break-words');
    if (headlineElement) {
      profile.headline = headlineElement.innerText.trim();
    }

    // Extract current position
    const experienceSection = document.querySelector('[data-view-name="profile-card"][id*="experience"]');
    if (experienceSection) {
      const firstExperience = experienceSection.querySelector('li');
      if (firstExperience) {
        const titleElement = firstExperience.querySelector('[data-field="experience_title"]');
        const companyElement = firstExperience.querySelector('[data-field="experience_company_name"]');

        if (titleElement) {
          profile.currentTitle = titleElement.innerText.trim();
        }
        if (companyElement) {
          profile.currentCompany = companyElement.innerText.trim().replace('·', '').trim();
        }
      }
    }

    // Alternative method for current position
    if (!profile.currentTitle || !profile.currentCompany) {
      const positionElements = document.querySelectorAll('.experience-item');
      if (positionElements.length > 0) {
        const currentPosition = positionElements[0];
        const titleEl = currentPosition.querySelector('.t-bold span[aria-hidden="true"]');
        const companyEl = currentPosition.querySelector('.t-14.t-normal span[aria-hidden="true"]');

        if (titleEl && !profile.currentTitle) {
          profile.currentTitle = titleEl.innerText.trim();
        }
        if (companyEl && !profile.currentCompany) {
          profile.currentCompany = companyEl.innerText.split('·')[0].trim();
        }
      }
    }

    // Extract location
    const locationElement = document.querySelector('.text-body-small.inline.t-black--light.break-words');
    if (locationElement) {
      profile.location = locationElement.innerText.trim();
    }

    // Extract about/summary
    const aboutSection = document.querySelector('[data-view-name="profile-card"][id*="about"]');
    if (aboutSection) {
      const aboutText = aboutSection.querySelector('.full-width span[aria-hidden="true"]');
      if (aboutText) {
        profile.about = aboutText.innerText.trim();
      }
    }

    // Extract experience
    const experienceItems = document.querySelectorAll('[data-view-name="profile-component-entity"]');
    experienceItems.forEach(item => {
      const titleEl = item.querySelector('[data-field="experience_title"]');
      const companyEl = item.querySelector('[data-field="experience_company_name"]');
      const durationEl = item.querySelector('[data-field="experience_date_range"]');
      const descriptionEl = item.querySelector('[data-field="experience_description"]');

      if (titleEl && companyEl) {
        profile.experience.push({
          title: titleEl.innerText.trim(),
          company: companyEl.innerText.trim().replace('·', '').trim(),
          duration: durationEl ? durationEl.innerText.trim() : '',
          description: descriptionEl ? descriptionEl.innerText.trim() : ''
        });
      }
    });

    // Extract skills
    const skillsSection = document.querySelector('[data-view-name="profile-card"][id*="skills"]');
    if (skillsSection) {
      const skillElements = skillsSection.querySelectorAll('[data-field="skill_name"]');
      skillElements.forEach(skillEl => {
        const skill = skillEl.innerText.trim();
        if (skill) {
          profile.skills.push(skill);
        }
      });
    }

    // Extract profile image
    const profileImage = document.querySelector('.pv-top-card__photo img') ||
                        document.querySelector('.presence-entity__image') ||
                        document.querySelector('[data-view-name="profile-photo-modal"] img');
    if (profileImage) {
      profile.profileImageUrl = profileImage.src;
    }

    // Log extracted data for debugging
    console.log('Extracted profile data:', profile);

  } catch (error) {
    console.error('Error extracting profile data:', error);
  }

  return profile;
}

// Function to create floating button
function createCaptureButton() {
  // Check if button already exists
  if (document.getElementById('recruitment-capture-btn')) {
    return;
  }

  const button = document.createElement('div');
  button.id = 'recruitment-capture-btn';
  button.innerHTML = `
    <button class="recruitment-btn">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
        <polyline points="17 21 17 13 7 13 7 21"></polyline>
        <polyline points="7 3 7 8 15 8"></polyline>
      </svg>
      <span>Capture Profile</span>
    </button>
    <div class="recruitment-status" id="recruitment-status"></div>
  `;

  document.body.appendChild(button);

  // Add click handler
  button.querySelector('.recruitment-btn').addEventListener('click', handleCaptureClick);
}

// Handle capture button click
async function handleCaptureClick() {
  const statusEl = document.getElementById('recruitment-status');
  const button = document.querySelector('.recruitment-btn');

  try {
    // Disable button and show loading
    button.disabled = true;
    button.classList.add('loading');
    statusEl.textContent = 'Extracting profile...';
    statusEl.className = 'recruitment-status show info';

    // Extract profile data
    const profileData = extractProfileData();

    if (!profileData.fullName) {
      throw new Error('Could not extract profile name');
    }

    // Get API key from storage
    const { apiKey, apiUrl } = await chrome.storage.sync.get(['apiKey', 'apiUrl']);

    if (!apiKey) {
      throw new Error('API key not configured. Please set it in extension options.');
    }

    const endpoint = apiUrl || 'http://localhost:3000';

    // Send to backend
    statusEl.textContent = 'Sending to CRM...';

    const response = await fetch(`${endpoint}/api/linkedin/profile`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey
      },
      body: JSON.stringify(profileData)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to save profile');
    }

    const result = await response.json();

    // Show success message
    statusEl.textContent = `✓ Profile captured! AI analysis started.`;
    statusEl.className = 'recruitment-status show success';

    // Store last captured profile
    await chrome.storage.local.set({
      lastCaptured: {
        name: profileData.fullName,
        url: profileData.url,
        timestamp: new Date().toISOString()
      }
    });

    // Hide status after 5 seconds
    setTimeout(() => {
      statusEl.className = 'recruitment-status';
    }, 5000);

  } catch (error) {
    console.error('Capture error:', error);
    statusEl.textContent = `Error: ${error.message}`;
    statusEl.className = 'recruitment-status show error';

    // Hide error after 5 seconds
    setTimeout(() => {
      statusEl.className = 'recruitment-status';
    }, 5000);

  } finally {
    // Re-enable button
    button.disabled = false;
    button.classList.remove('loading');
  }
}

// Initialize extension when page loads
function initialize() {
  // Only run on LinkedIn profile pages
  if (!window.location.href.includes('linkedin.com/in/')) {
    return;
  }

  // Wait for page to load key elements
  const checkInterval = setInterval(() => {
    const nameElement = document.querySelector('h1.text-heading-xlarge');
    if (nameElement) {
      clearInterval(checkInterval);
      createCaptureButton();
    }
  }, 1000);

  // Stop checking after 10 seconds
  setTimeout(() => {
    clearInterval(checkInterval);
  }, 10000);
}

// Run initialization
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}

// Handle navigation changes (LinkedIn is a SPA)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    if (url.includes('linkedin.com/in/')) {
      setTimeout(initialize, 1000);
    }
  }
}).observe(document, { subtree: true, childList: true });